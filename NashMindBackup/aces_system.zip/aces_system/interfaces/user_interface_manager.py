
import time
import uuid

class UserInputProcessor:
    """
    يعالج المدخلات من المستخدمين، بما في ذلك الأوامر النصية، المدخلات الصوتية، والإيماءات.
    """
    def __init__(self):
        self.input_history = []
        self.supported_input_types = ["text", "voice", "gesture"]

    def process_input(self, input_data):
        """معالجة المدخلات الواردة من المستخدم.
        المدخلات: input_data (قاموس يحتوي على نوع المدخلات والمحتوى).
        المخرجات: قاموس يمثل المدخلات المعالجة.
        """
        input_type = input_data.get("type")
        content = input_data.get("content")
        timestamp = time.time()
        input_id = str(uuid.uuid4())

        processed_input = {
            "id": input_id,
            "type": input_type,
            "content": content,
            "timestamp": timestamp,
            "status": "unprocessed"
        }

        if input_type not in self.supported_input_types:
            processed_input["status"] = "unsupported_type"
            print(f"  [InputProcessor] نوع المدخلات غير مدعوم: {input_type}")
            self.input_history.append(processed_input)
            return processed_input

        # محاكاة معالجة المدخلات بناءً على النوع
        if input_type == "text":
            processed_input["processed_content"] = content.strip().lower()
            processed_input["status"] = "processed"
            print(f"  [InputProcessor] معالجة مدخل نصي: \"{content}\"")
        elif input_type == "voice":
            # هنا يمكن دمج خدمة تحويل الكلام إلى نص
            processed_input["processed_content"] = f"[تم تحويل الصوت إلى نص]: {content}"
            processed_input["status"] = "processed"
            print(f"  [InputProcessor] معالجة مدخل صوتي: \"{content}\"")
        elif input_type == "gesture":
            # هنا يمكن دمج خدمة التعرف على الإيماءات
            processed_input["processed_content"] = f"[تم التعرف على الإيماءة]: {content}"
            processed_input["status"] = "processed"
            print(f"  [InputProcessor] معالجة مدخل إيماءة: \"{content}\"")

        self.input_history.append(processed_input)
        return processed_input

    def get_input_history(self):
        return self.input_history


class SystemOutputFormatter:
    """
    يقوم بتنسيق مخرجات النظام للاستهلاك البشري، بما في ذلك النصوص، الرسومات، والصوت.
    """
    def __init__(self):
        self.supported_output_formats = ["text", "json", "html", "audio", "visual"]

    def format_output(self, output_data, desired_format="text"):
        """تنسيق مخرجات النظام.
        المدخلات: output_data (قاموس يحتوي على البيانات الخام)، desired_format (التنسيق المطلوب).
        المخرجات: سلسلة نصية أو كائن يمثل المخرجات المنسقة.
        """
        if desired_format not in self.supported_output_formats:
            print(f"  [OutputFormatter] تنسيق المخرجات غير مدعوم: {desired_format}")
            return {"error": "Unsupported output format", "format": desired_format}

        print(f"  [OutputFormatter] تنسيق المخرجات إلى {desired_format}...")
        formatted_output = {}

        if desired_format == "text":
            formatted_output["content"] = self._format_as_text(output_data)
            formatted_output["type"] = "text"
        elif desired_format == "json":
            formatted_output["content"] = json.dumps(output_data, indent=2, ensure_ascii=False)
            formatted_output["type"] = "json"
        elif desired_format == "html":
            formatted_output["content"] = self._format_as_html(output_data)
            formatted_output["type"] = "html"
        elif desired_format == "audio":
            # هنا يمكن دمج خدمة تحويل النص إلى كلام
            formatted_output["content"] = "[تم تحويل النص إلى صوت]: {}".format(output_data.get("response", ""))
            formatted_output["type"] = "audio"
        elif desired_format == "visual":
            # هنا يمكن دمج خدمة توليد الرسومات أو المرئيات
            formatted_output["content"] = "[تم توليد مرئيات]: {}".format(output_data.get("visualization_data", ""))
            formatted_output["type"] = "visual"

        return formatted_output

    def _format_as_text(self, data):
        text_output = ""
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, dict):
                    text_output += f"{key.replace('_', ' ').title()}:\n"
                    for sub_key, sub_value in value.items():
                        text_output += f"  - {sub_key.replace('_', ' ').title()}: {sub_value}\n"
                elif isinstance(value, list):
                    text_output += f"{key.replace('_', ' ').title()}:\n"
                    for item in value:
                        text_output += f"  - {item}\n"
                else:
                    text_output += f"{key.replace('_', ' ').title()}: {value}\n"
        else:
            text_output = str(data)
        return text_output

    def _format_as_html(self, data):
        html_output = "<!DOCTYPE html>\n<html>\n<head><title>ACES Output</title></head><body>\n"
        html_output += "<h1>ACES System Response</h1>\n"
        if isinstance(data, dict):
            for key, value in data.items():
                html_output += f"<h2>{key.replace('_', ' ').title()}</h2>\n"
                if isinstance(value, dict):
                    html_output += "<ul>\n"
                    for sub_key, sub_value in value.items():
                        html_output += f"<li><strong>{sub_key.replace('_', ' ').title()}:</strong> {sub_value}</li>\n"
                    html_output += "</ul>\n"
                elif isinstance(value, list):
                    html_output += "<ul>\n"
                    for item in value:
                        html_output += f"<li>{item}</li>\n"
                    html_output += "</ul>\n"
                else:
                    html_output += f"<p>{value}</p>\n"
        else:
            html_output += f"<p>{data}</p>\n"
        html_output += "</body>\n</html>"
        return html_output


class UserInterfaceManager:
    """
    يدير التفاعل الشامل مع المستخدم، بما في ذلك معالجة المدخلات وتنسيق المخرجات.
    """
    def __init__(self, communication_manager):
        self.input_processor = UserInputProcessor()
        self.output_formatter = SystemOutputFormatter()
        self.communication_manager = communication_manager
        self._setup_internal_subscriptions()
        print("تم تهيئة مدير واجهة المستخدم.")

    def _setup_internal_subscriptions(self):
        """إعداد الاشتراكات الداخلية لمعالجة الرسائل من المكونات الأخرى."""
        self.communication_manager.subscribe_internal_messages(
            "UserInterfaceManager_Input", self._handle_internal_input_request)
        self.communication_manager.subscribe_internal_messages(
            "UserInterfaceManager_Output", self._handle_internal_output_display)
        print("  مدير واجهة المستخدم مشترك في ناقل الرسائل الداخلي.")

    def _handle_internal_input_request(self, message):
        """معالجة طلبات المدخلات الداخلية (مثال: طلب معلومات من المستخدم)."""
        print("  [UI Manager] تلقى طلب مدخلات داخلي: {}".format(message["payload"]))
        # في نظام حقيقي، سيتم توجيه هذا إلى واجهة المستخدم الفعلية لطلب المدخلات
        # هنا، سنقوم بمحاكاة رد بسيط
        simulated_user_response = {"type": "text", "content": "هذه استجابة محاكاة لطلبك.", "source_message_id": message["id"]}
        processed_response = self.input_processor.process_input(simulated_user_response)
        self.communication_manager.publish_internal_message(
            "user_input_response", processed_response, "UserInterfaceManager")

    def _handle_internal_output_display(self, message):
        """معالجة طلبات عرض المخرجات الداخلية (مثال: عرض نتائج للمستخدم)."""
        print("  [UI Manager] تلقى طلب عرض مخرجات داخلي: {}".format(message["payload"]))
        output_data = message["payload"].get("data", {})
        desired_format = message["payload"].get("format", "text")
        
        formatted_output = self.output_formatter.format_output(output_data, desired_format)
        
        # في نظام حقيقي، سيتم إرسال هذا إلى واجهة المستخدم الفعلية للعرض
        print("  [UI Manager] تم تنسيق المخرجات للعرض: \n{}...".format(formatted_output.get("content", "")[:200]))
        # يمكن نشر رسالة داخلية أخرى لتأكيد العرض أو إرسالها إلى قناة خارجية
        self.communication_manager.publish_internal_message(
            "output_displayed_confirmation", {"status": "displayed", "format": desired_format}, "UserInterfaceManager")

    def process_user_interaction(self, raw_input_data, output_format="text"):
        """نقطة دخول لمعالجة تفاعل المستخدم الكامل.
        تستقبل المدخلات الخام، تعالجها، وتنسق المخرجات.
        """
        print("\n--- معالجة تفاعل المستخدم ---")
        processed_input = self.input_processor.process_input(raw_input_data)
        
        if processed_input["status"] == "unsupported_type":
            return self.output_formatter.format_output({"response": "عذرًا، نوع المدخلات هذا غير مدعوم حاليًا."}, output_format)

        # هنا، سيتم إرسال المدخلات المعالجة إلى المكونات الأساسية للنظام (عبر ناقل الرسائل الداخلي)
        self.communication_manager.publish_internal_message(
            "user_command", processed_input, "UserInterfaceManager")
        
        # محاكاة استجابة النظام (في نظام حقيقي، ستأتي الاستجابة من المكونات الأساسية)
        simulated_system_response = {
            "response": "تم استلام أمرك: \"{}\". جاري المعالجة...".format(processed_input["processed_content"]),
            "status": "processing",
            "request_id": processed_input["id"]
        }
        
        # نشر الاستجابة لمحاكي العرض
        self.communication_manager.publish_internal_message(
            "UserInterfaceManager_Output", {"data": simulated_system_response, "format": output_format}, "UserInterfaceManager")

        return self.output_formatter.format_output(simulated_system_response, output_format)


# مثال على كيفية استخدام UserInterfaceManager (للتوضيح فقط)
if __name__ == "__main__":
    from communication_manager import CommunicationManager
    comm_manager = CommunicationManager()
    ui_manager = UserInterfaceManager(comm_manager)

    # محاكاة تفاعل المستخدم
    print("\n--- التفاعل الأول: مدخل نصي ---")
    user_input1 = {"type": "text", "content": "ما هو الغرض من وجودي؟"}
    response1 = ui_manager.process_user_interaction(user_input1, "text")
    print("استجابة النظام 1:\n{}".format(response1["content"]))

    print("\n--- التفاعل الثاني: مدخل صوتي ---")
    user_input2 = {"type": "voice", "content": "أريد تقريرًا عن حالة النظام."}
    response2 = ui_manager.process_user_interaction(user_input2, "json")
    print("استجابة النظام 2:\n{}".format(response2["content"]))

    print("\n--- التفاعل الثالث: مدخل غير مدعوم ---")
    user_input3 = {"type": "brainwave", "content": "أفكار مباشرة."}
    response3 = ui_manager.process_user_interaction(user_input3, "text")
    print("استجابة النظام 3:\n{}".format(response3["content"]))

    # معالجة الرسائل الداخلية التي تم نشرها
    print("\n--- معالجة الرسائل الداخلية بعد التفاعلات ---")
    comm_manager.process_internal_messages()
    comm_manager.process_internal_messages() # لمعالجة رسائل الرد

    print("\n--- حالة مدير الاتصالات بعد التفاعلات ---")
    print(comm_manager.get_status())




